export const NutritionistLecture = () => {
    return(
        <>
        <div className="cooking_method" id="lecture">
            <p className="sales_point">栄養士レクチャー</p>
            <p>お子様やご自身の健康をさらに意識した料理や意識など、<br />お客様に沿ったレシピでサポートします。</p>
            <div className="eiyoshi">
                <figure><img src="./images/eiyoshi_m.jpg" alt="栄養士" /></figure>
            </div>
            <div className="feature_all_btn">
                詳細情報準備中
            </div>
        </div>
        </>
    )
}