export const ExampleMalnutrition = () => {
    return(
        <>
        <div className="cooking_method">
            <p className="sales_point">栄養不足の一例</p>
            <p>体験に基づいた栄養のエピソードをご紹介します。<br />きっとあなたのお役に立つでしょう。</p>
            <div className="method_type_select lack_nutrients">
                <div className="method_01 malnutrition">
                    <figure>
                        <img src="./images/eiyo_busoku_1.jpg" alt="栄養不足1" />
                    </figure>
                    <figcaption>疎かにしてはいけない栄養不足の恐怖</figcaption>
                </div>
                <div className="method_01 malnutrition">
                    <figure>
                        <img src="./images/eiyo_busoku_2.jpg" alt="栄養不足2" />
                    </figure>
                    <figcaption>疎かにしてはいけない栄養不足の恐怖</figcaption>
                </div>
                <div className="method_01 malnutrition">
                    <figure>
                        <img src="./images/eiyo_busoku_3.jpg" alt="栄養不足3" />
                    </figure>
                    <figcaption>疎かにしてはいけない栄養不足の恐怖</figcaption>
                </div>
            </div>
            <div className="feature_all_btn">
                栄養不足の一例を詳しく！
            </div>
        </div>
        </>
    )
}