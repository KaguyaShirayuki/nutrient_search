export const NutrientSearch = () => {
    return(
        <div>こちらは検索画面になります。</div>
    )
}