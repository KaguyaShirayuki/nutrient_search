// import React, { useState, useEffect } from "react";

import { Header } from "./Header/Header";
import { Main } from "./Main/Main";
import { Footer } from "./Footer";

import "../css/style.css";

export const NutrientTop = () => {
   return (
    <>
    <div id="wrapper">
        <Header />
        <Main />
        <Footer />
    </div>
    </>
   )
}