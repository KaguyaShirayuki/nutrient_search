export const NutrientDetail = () => {
    return(
        <div>こちらは詳細画面になります。</div>
    )
}