
export const HeaderNavigation = () => {
    return(
        <>
        <nav className="header-top">
            <div className="logo">
                <img src="./images/title_logo.png" alt="タイトルロゴ" />
            </div>
            <div className="navigation-menu">
                <ul className="header_navi">
                    <li><a href="#feature">サービスの特徴</a></li>
                    <li><a href="#purpose">目的別調理法</a></li>
                    <li><a href="#nutrients">5大栄養素</a></li>
                    <li><a href="#lecture">プロ栄養士</a></li>
                    <li><a href="#faq">よくある質問</a></li>
                </ul>
            </div>
            <div className="recipe_search_btn">
                <p>料理を<br className="br-sp" />検索</p>
            </div>
            <div className="sp_nav_btn">三</div>
        </nav>
        </>
    )
}