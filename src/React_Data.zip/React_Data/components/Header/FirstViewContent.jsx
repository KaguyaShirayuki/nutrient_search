import { BrowserRouter, Link, Switch, Route } from "react-router-dom";

export const FirstViewContent = () => {
    return(
        <>
        <div className="first_view">
            <div className="first_view_content">
                <div className="first_view_left">
                    <div className="first_view_row">
                        <div className="days">1/31<br className="br-pc" />（水）</div>
                        <div className="todays_appel_title">太陽の恵みを一新に浴びた<br className="br-sp" />新鮮なビタミンE
                        <p>冬の厳しい環境に、身体の芯からあたたまるひと時をお楽しみいただけます</p></div>
                    </div>
                    <div className="first_view_row">
                        <figure><img src="./images/today_food_picture_1.jpg" alt="サーモンソテー" /><figcaption>サーモンソテー</figcaption></figure>
                        <figure><img src="./images/today_food_picture_2.jpg" alt="ステーキ" /><Link to ="/detail"><figcaption>ステーキ</figcaption></Link></figure>
                    </div>
                    <div className="week_recipe_btn"><Link to ="/search">今週のレシピを見る</Link></div>
                </div>
                <div className="side_page">
                    <div className="side_panel">
                        <h2>人気の調理レシピ</h2>
                        <p className="red_ruby">cooking recipes</p>
                    
                        <div className="ranking_recipe">
                            <div className="top1">
                                <figure><img src="./images/best1.png" width="" alt="best1" /></figure>
                                <p>お寿司</p>
                            </div>
                            <div className="top1">
                                <figure><img src="./images/best2.png" width="" alt="best2" /></figure>
                                <p>おそば</p>
                            </div>
                            <div className="top1">
                                <figure><img src="./images/best3.png" width="" alt="best3" /></figure>
                                <p>みそ汁</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </>
    )
}