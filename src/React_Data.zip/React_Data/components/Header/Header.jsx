import { SearchRecipeArea } from "./SearchRecipeArea";
import { HeaderNavigation } from "./HeaderNavigation";
import { FirstViewContent } from "./FirstViewContent";


export const Header = () => {
    // useStateを設定する

    // useEffectを設定する


// Function関数を定義する


    return (
        <>
        <header>
            <SearchRecipeArea />
            <HeaderNavigation />
            <FirstViewContent />
        </header>
        </>
    )
}